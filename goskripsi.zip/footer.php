<footer class="page-footer cyan">
    <div class="footer-copyright blue grey darken-4">
        Copyright &copy; 2015 GoSkripsi | All rights reserved |
        <a class="text" href="#">  Syarat dan Ketentuan Layanan</a>
    </div>

</footer>