# AdaFlorists - Sistem Jual Beli Tanaman Hias Online

untuk :
 - Kelompok 7



## Dipersiapkan oleh:
- Iqbal Abiyoga	(G64140014)
- Rahmad Ilham Pratama	(G64140016)
- David Tahi Ulubalang	(G64140060)
- Wulan Maulida	(G64140061)

### Departemen Ilmu Komputer
#### Fakultas Matematika dan Ilmu Pengetahuan Alam
#### Institut Pertanian Bogor

#

>Tanaman hias adalah semua jenis tanaman yang bermanfaat untuk menambah keindahan dan kecantikan baik itu tanaman hias bunga, daun, batang maupun akar. Tanaman hias umumnya sengaja ditanam dengan tujuan untuk memberikan kesan indah baik untuk dalam ruangan maupun untuk diluar ruangan. Tanaman hias tidak hanya memberikan unsur keindahan saja namun juga memberikan berbagai manfaat.
Para kolektor tanaman hias mencari tanaman hias hingga keluar daerah maupun pergi ke luar Indonesia untuk mendapatkan jenis tanaman yang diinginkan. Namun dengan terkendala waktu dan pekerjaan, kolektor tanaman hias kesulitan untuk mendapatkan jenis tanaman hias yang diinginkan. 
Seiring dengan berkembangnya teknologi dan informasi, seperti internet, segala bentuk transaksi  jual beli  dapat dilakukan melalui web browser yang terkoneksi internet. Transaksi jual beli  dapat dilakukan tanpa bertemu secara langsung. Dengan menggunakan teknologi intenet dan aplikasi yang dibuat, memudahkan kolektor tanaman hias ataupun pecinta tanaman lainnya untuk melihat informasi produk yang dijual oleh admin. akan membuat sebuah aplikasi berbasis web untuk mempermudah kolektor tanaman hias dalam  membeli tanaman hias tanpa perlu mendatangi tempat penjualan tanaman hias. Pembeli juga dapat memesan atau melihat informasi tanaman hias yang dijual. 


### Versi Sistem
1.1
### Dikembangkan dengan

Adaflorist dikembangkan menggunakan perangkat lunak aplikasi : 

* [XAMPP] - WebApps Development Package, including : Apache PHP Local Server, MySSQL DBMS
* [Adobe Brackets] - Code the web, powerfull text editor
* [MaterializeCSS] - CSS, JS, anda JQuery Package with material design style, front-end design


### Akses Online
AdaFlorist sudah dapat diakses melalui laman : http://adaflorist.hol.es
dihosting menggunakan :
India Hostinger